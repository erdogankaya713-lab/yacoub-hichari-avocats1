# Yacoub & Hichari Avocats — site + administration

Projet regroupant le site public multilingue (FR par défaut, AR, EN), l’interface de gestion `/settings`, l’API Express et PostgreSQL.

## Structure
- `public/index.html` : site public responsive
- `public/settings.html` : interface de gestion
- `src/` : API, sessions, authentification et routes
- `database/schema.sql` : schéma PostgreSQL
- `uploads/` : stockage local temporaire des photos

## Prérequis
Node.js 20+ et PostgreSQL 14+.

## Installation
1. Copier `.env.example` vers `.env` et renseigner les valeurs. Ne jamais publier `.env`.
2. `npm install`
3. `npm run db:init`
4. `npm run admin:create` puis définir un identifiant et un mot de passe fort.
5. `npm run dev` (développement) ou `npm run build && npm start` (production).
6. Ouvrir `/` pour le site et `/settings` pour l’administration.

## Important avant production
- Configurer HTTPS, sauvegardes PostgreSQL et les variables d’environnement.
- Les photos sont actuellement stockées dans `uploads/`. Sur un hébergement à disque éphémère, utiliser Cloudinary ou un stockage persistant.
- L’interface actuelle permet la connexion, l’ajout de profils et la gestion WhatsApp. L’édition/suppression de profils et la gestion complète de tous les contenus ne sont pas encore implémentées.
- Vérifier les coordonnées et contenus avec le cabinet avant publication. Aucun compte administrateur n’est préconfiguré.
