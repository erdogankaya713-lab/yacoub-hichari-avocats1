CREATE TABLE IF NOT EXISTS admins (
 id BIGSERIAL PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, must_change_password BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS site_settings (
 id BIGSERIAL PRIMARY KEY, setting_key VARCHAR(100) UNIQUE NOT NULL,
 value JSONB NOT NULL DEFAULT '{}'::jsonb, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS lawyer_profiles (
 id BIGSERIAL PRIMARY KEY, role VARCHAR(30) NOT NULL CHECK(role IN ('managing_partner','lawyer')),
 is_published BOOLEAN NOT NULL DEFAULT FALSE, photo_path TEXT,
 sort_order INTEGER NOT NULL DEFAULT 0, created_at TIMESTAMPTZ DEFAULT NOW(),
 updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS lawyer_profile_translations (
 id BIGSERIAL PRIMARY KEY, profile_id BIGINT REFERENCES lawyer_profiles(id) ON DELETE CASCADE,
 language VARCHAR(2) CHECK(language IN ('fr','ar','en')), full_name VARCHAR(180),
 title VARCHAR(180), biography TEXT, expertise JSONB DEFAULT '[]', education JSONB DEFAULT '[]',
 UNIQUE(profile_id,language)
);
CREATE TABLE IF NOT EXISTS enquiries (
 id BIGSERIAL PRIMARY KEY, full_name VARCHAR(180) NOT NULL, email VARCHAR(254) NOT NULL,
 phone VARCHAR(40), preferred_language VARCHAR(2) DEFAULT 'fr', message TEXT NOT NULL,
 status VARCHAR(20) DEFAULT 'new', created_at TIMESTAMPTZ DEFAULT NOW()
);
INSERT INTO site_settings(setting_key,value) VALUES
('whatsapp','{"enabled":false,"phone":"","greeting":{"fr":"","ar":"","en":""}}'),
('contact','{"address":"","phone":"","email":"","maps_url":""}')
ON CONFLICT(setting_key) DO NOTHING;
