import pg from 'pg'; import { env } from './config.js';
export const pool = new pg.Pool({connectionString:env.DATABASE_URL,
 ssl:env.NODE_ENV==='production'?{rejectUnauthorized:true}:undefined});
