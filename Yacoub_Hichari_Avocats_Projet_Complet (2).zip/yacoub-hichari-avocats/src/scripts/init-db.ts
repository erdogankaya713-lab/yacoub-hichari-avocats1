import fs from 'node:fs';import {pool} from '../db.js';
try{await pool.query(fs.readFileSync(new URL('../../database/schema.sql',import.meta.url),'utf8'));console.log('Schema initialized.')}finally{await pool.end()}
