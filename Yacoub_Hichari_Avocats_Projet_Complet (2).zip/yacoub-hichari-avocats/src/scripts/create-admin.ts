import readline from 'node:readline/promises';import {stdin,stdout} from 'node:process';
import argon2 from 'argon2';import {pool} from '../db.js';
const rl=readline.createInterface({input:stdin,output:stdout});
try{const username=(await rl.question('Admin username: ')).trim();const password=await rl.question('Temporary password (14+ chars): ');
if(!/^[a-zA-Z0-9._-]{4,80}$/.test(username)||password.length<14)throw Error('Invalid username or password length.');
const hash=await argon2.hash(password,{type:argon2.argon2id});
await pool.query('INSERT INTO admins(username,password_hash,must_change_password) VALUES($1,$2,true)',[username,hash]);
console.log('Administrator created.');}finally{rl.close();await pool.end()}
