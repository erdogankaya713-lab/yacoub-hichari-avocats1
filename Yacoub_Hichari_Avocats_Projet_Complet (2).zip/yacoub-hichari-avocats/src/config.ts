import 'dotenv/config';
import { z } from 'zod';
export const env = z.object({
 NODE_ENV:z.enum(['development','test','production']).default('development'),
 PORT:z.coerce.number().default(4000), DATABASE_URL:z.string().min(1),
 SESSION_SECRET:z.string().min(32), APP_ORIGIN:z.string().url(),
 UPLOAD_DIR:z.string().default('uploads'), MAX_UPLOAD_MB:z.coerce.number().positive().max(10).default(5)
}).parse(process.env);
