import {Router} from 'express'; import multer from 'multer'; import path from 'node:path';
import crypto from 'node:crypto'; import fs from 'node:fs'; import {env} from '../config.js';
import {pool} from '../db.js'; import {requireAdmin} from '../middleware/auth.js';
export const lawyersRouter=Router(); fs.mkdirSync(env.UPLOAD_DIR,{recursive:true});
const storage=multer.diskStorage({destination:(_r,_f,cb)=>cb(null,env.UPLOAD_DIR),
 filename:(_r,f,cb)=>cb(null,crypto.randomUUID()+path.extname(f.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:env.MAX_UPLOAD_MB*1024*1024},
 fileFilter:(_r,f,cb)=>cb(null,['image/jpeg','image/png','image/webp'].includes(f.mimetype))});
lawyersRouter.post('/',requireAdmin,upload.single('photo'),async(req,res,next)=>{
 const c=await pool.connect();try{await c.query('BEGIN');
 const role=req.body.role==='managing_partner'?'managing_partner':'lawyer';
 const p=await c.query('INSERT INTO lawyer_profiles(role,photo_path) VALUES($1,$2) RETURNING id',[role,req.file?.filename??null]);
 const id=p.rows[0].id;
 for(const lang of ['fr','ar','en'])await c.query(
 'INSERT INTO lawyer_profile_translations(profile_id,language,full_name,title,biography) VALUES($1,$2,$3,$4,$5)',
 [id,lang,req.body[lang+'_name']||null,req.body[lang+'_title']||null,req.body[lang+'_biography']||null]);
 await c.query('COMMIT');res.status(201).json({id:Number(id),photo:req.file?.filename??null});
 }catch(e){await c.query('ROLLBACK');next(e)}finally{c.release()}});
lawyersRouter.get('/',async(_req,res,next)=>{try{
 const r=await pool.query("SELECT p.id,p.role,p.photo_path,p.is_published,jsonb_object_agg(t.language,jsonb_build_object('name',t.full_name,'title',t.title,'biography',t.biography)) AS translations FROM lawyer_profiles p LEFT JOIN lawyer_profile_translations t ON t.profile_id=p.id WHERE p.is_published=true GROUP BY p.id ORDER BY p.sort_order,p.id");
 res.json(r.rows)}catch(e){next(e)}});
