import {Router} from 'express'; import argon2 from 'argon2'; import {z} from 'zod';
import {pool} from '../db.js'; import {requireAdmin} from '../middleware/auth.js';
export const authRouter=Router();
const schema=z.object({username:z.string().min(1).max(80),password:z.string().min(1).max(200)});
authRouter.post('/login',async(req,res,next)=>{try{
 const v=schema.safeParse(req.body); if(!v.success)return res.status(400).json({error:'Invalid input'});
 const q=await pool.query('SELECT id,password_hash,must_change_password FROM admins WHERE username=$1',[v.data.username]);
 const a=q.rows[0]; if(!a||!(await argon2.verify(a.password_hash,v.data.password)))return res.status(401).json({error:'Invalid username or password'});
 req.session.regenerate(err=>{if(err)return next(err);req.session.adminId=Number(a.id);
 req.session.save(e=>e?next(e):res.json({authenticated:true,mustChangePassword:a.must_change_password}));});
 }catch(e){next(e)}});
authRouter.post('/logout',(req,res,next)=>req.session.destroy(e=>e?next(e):res.clearCookie('sid').status(204).end()));
authRouter.get('/me',requireAdmin,(_req,res)=>res.json({authenticated:true}));
