import {Router} from 'express'; import {z} from 'zod'; import {pool} from '../db.js';
import {requireAdmin} from '../middleware/auth.js';
export const settingsRouter=Router();
const schema=z.object({enabled:z.boolean(),phone:z.string().max(30),
 greeting:z.object({fr:z.string().max(500),ar:z.string().max(500),en:z.string().max(500)})});
settingsRouter.get('/whatsapp',requireAdmin,async(_req,res,next)=>{try{
 const r=await pool.query("SELECT value FROM site_settings WHERE setting_key='whatsapp'");
 res.json(r.rows[0]?.value??{enabled:false,phone:'',greeting:{fr:'',ar:'',en:''}});
 }catch(e){next(e)}});
settingsRouter.put('/whatsapp',requireAdmin,async(req,res,next)=>{try{
 const v=schema.safeParse(req.body);if(!v.success)return res.status(400).json({error:'Invalid settings'});
 await pool.query("INSERT INTO site_settings(setting_key,value) VALUES('whatsapp',$1::jsonb) ON CONFLICT(setting_key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()",[JSON.stringify(v.data)]);
 res.json({saved:true});
 }catch(e){next(e)}});
settingsRouter.get('/whatsapp/public',async(_req,res,next)=>{try{
 const r=await pool.query("SELECT value FROM site_settings WHERE setting_key='whatsapp'");
 const v=r.rows[0]?.value??{};res.json({enabled:v.enabled===true,phone:v.phone||'',greeting:v.greeting||{}});
 }catch(e){next(e)}});
