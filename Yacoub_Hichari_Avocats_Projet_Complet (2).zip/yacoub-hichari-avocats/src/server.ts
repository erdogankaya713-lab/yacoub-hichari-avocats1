import express from 'express';import path from 'node:path';import {fileURLToPath} from 'node:url';import session from 'express-session';import pgSession from 'connect-pg-simple';
import helmet from 'helmet';import rateLimit from 'express-rate-limit';import cookieParser from 'cookie-parser';
import csrf from 'csurf';import {env} from './config.js';import {pool} from './db.js';
import {authRouter} from './routes/auth.js';import {settingsRouter} from './routes/settings.js';import {lawyersRouter} from './routes/lawyers.js';
declare module 'express-session'{interface SessionData{adminId?:number}}
const __dirname=path.dirname(fileURLToPath(import.meta.url));const projectRoot=path.resolve(__dirname,'..');
const app=express();const PgStore=pgSession(session);app.set('trust proxy',env.NODE_ENV==='production'?1:false);
app.use(helmet({contentSecurityPolicy:false}));app.use(express.json({limit:'1mb'}));app.use(cookieParser());
app.use(session({name:'sid',store:new PgStore({pool,tableName:'user_sessions',createTableIfMissing:true}),
secret:env.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,
secure:env.NODE_ENV==='production',sameSite:'lax',maxAge:8*60*60*1000}}));
app.use('/uploads',express.static(path.resolve(env.UPLOAD_DIR),{fallthrough:false,index:false}));
app.use('/api/auth/login',rateLimit({windowMs:900000,limit:10}));
app.use('/api',csrf({cookie:false,ignoreMethods:['GET','HEAD','OPTIONS']}));
app.get('/api/csrf-token',(req,res)=>res.json({csrfToken:req.csrfToken()}));
app.use('/api/auth',authRouter);app.use('/api/settings',settingsRouter);app.use('/api/lawyers',lawyersRouter);
app.get('/settings',(req,res)=>res.sendFile(path.join(projectRoot,'public','settings.html')));
app.use(express.static(path.join(projectRoot,'public')));
app.get('/api/health',(_req,res)=>res.json({status:'ok',service:'yacoub-hichari-api'}));
app.use((err:any,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{
console.error(err);res.status(err.status||500).json({error:env.NODE_ENV==='production'?'Server error':err.message})});
app.listen(env.PORT,()=>console.log('API listening on '+env.PORT));
